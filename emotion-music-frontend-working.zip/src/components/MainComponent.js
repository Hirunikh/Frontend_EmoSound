import React, { useEffect, useRef, useState } from 'react';
import Webcam from 'react-webcam';
import "./MainComponent.css"

let spotifyEmbedController = null
let captureInterval = null

window.onSpotifyIframeApiReady = (IFrameAPI) => {
    const element = document.getElementById('embed-iframe');
    const options = {
        width: '100%',
        height: '100%',
        uri: 'spotify:track:2p8IUWQDrpjuFltbdgLOag'
    };
    const callback = (EmbedController) => {
        spotifyEmbedController = EmbedController;
    };
    IFrameAPI.createController(element, options, callback);
};

const MainComponent = ({ onEmotionDetection }) => {
    const webcamRef = useRef(null);
    const [recommendedMusic, setRecommendedMusic] = useState([]);
    const [automaticMode, setAutomaticMode] = useState(false);

    const captureImageAndSend = async () => {
        const imageSrc = webcamRef.current.getScreenshot();
        sendImageToBackend(imageSrc);
    };

    const sendImageToBackend = async (imageSrc) => {
        // Send image to backend for emotion detection
        try {
            const response = await fetch('http://localhost:5000/get_recommendations', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ image: imageSrc }),
                mode: 'cors', // Ensure CORS is enabled
            });
            const data = await response.json();
            renderRecommendations(data.music);
        } catch (error) {
            console.error('Error during emotion detection:', error);
        }
    };


    const renderRecommendations = (data) => {
        let renderList = data.map(song =>
            <div key={song.uri} class="song-item">
                <div class="song-info">
                    <div class="song-name">{song.name}</div>
                    <div class="artist">{song.artist}</div>
                    <div class="duration">{song.duration}</div>
                </div>
                <button class="play-button" onClick={() => handlePlayMusic(song.uri)}><i class="material-icons">play_arrow</i></button>
            </div>
        );
        setRecommendedMusic(renderList);
    }

    const handlePlayMusic = (uri) => {
        spotifyEmbedController.loadUri(uri);
        spotifyEmbedController.play();
    };

    useEffect(() => {
        captureImageAndSend();
    }, [])


    return (
        <div class="container">
            <div class="webcam-container">
                <Webcam
                    audio={false}
                    ref={webcamRef}
                    className="webcam-video"
                    screenshotFormat="image/jpeg"
                    width="100%" // Ensure webcam takes full width of its container
                />
                <div class="controls-container">
                    <div class="toggle-container">
                        <span>Automatic Mode</span>
                        <label class="toggle-switch">
                            <input type="checkbox" value={automaticMode}
                                onChange={event => {
                                    let newVal = !automaticMode;
                                    setAutomaticMode(newVal);
                                    if (newVal) {
                                        captureInterval = setInterval(() => {
                                            captureImageAndSend();
                                        }, 5000); // Capture image every 5 seconds
                                    } else {
                                        clearInterval(captureInterval)
                                    }
                                }}>
                            </input>
                            <span class="slider"></span>
                        </label>
                    </div>
                    {!automaticMode && <button class="button" onClick={captureImageAndSend}>Capture</button>}
                </div>
            </div>
            <div class="music-container">
                <div class="player">
                    <div id="embed-iframe"></div>
                </div>
                <h2 class="recommendations">Recommendations</h2>
                <div class="songs-container">
                    <div class="song-list">
                        {recommendedMusic}
                    </div>
                </div>
            </div>
        </div>

    );
};

export default MainComponent;